<?php

$config["sitename"] = "Hotel La Molina";
$config["sitedescription"] = "";
$config["author"] = "Ing. Daniel Pomalaza";
$config["owner"] = "Online Conexion";
?>
